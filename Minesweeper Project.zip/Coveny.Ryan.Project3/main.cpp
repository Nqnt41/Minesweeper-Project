#include "Minesweeper.h"
#include "Board.h"
/// Access by int value = Minesweeper::Integer(1, 2) e.g.
#include <SFML/Graphics.hpp>
#include <vector>
#include <iostream>
#include <ctime>
#include <map>
#include <unordered_map>
using namespace std;
using std::unordered_map;
using std::string;

int main()
{
    Minesweeper minesweeper;
    Board board;

    while (!board.gameOver) {
        // Load board data into vector
        board.LoadBoardData("config");
        // First, load window:
        sf::RenderWindow window(sf::VideoMode(board.width, board.height), "Minesweeper");
        // Create map including every sprite:
        unordered_map<string, sf::Sprite> sprites = minesweeper.CreateSpriteMap();

        // Loop allowing for actual game window:
        while (window.isOpen()) {
            sf::Event event;

            // Ability to close the tab
            while (window.pollEvent(event)) {
                board.gameOver = true;
                // Event refers to window state: if event type is closed, close window.
                if (event.type == sf::Event::Closed) {
                    window.close();
                }
            }

            /// Three steps of drawing board:
            // Step 1: Clear anything already drawn:
            window.clear(sf::Color(255, 255, 255, 255));

            // Step 2: Draw whatever is needed:
            //window.draw(sprites["debug"]);
            board.DrawBoard(window, sprites, event);

            // Step 3: Display whatever was drawn:
            window.display();
        }
    }
    minesweeper.Clear();
    return 0;
}