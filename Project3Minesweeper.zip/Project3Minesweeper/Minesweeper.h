#include <SFML/Graphics.hpp>
#include <vector>
#include <iostream>
#include <random>
#include <unordered_map>
#include <ctime>
#pragma once
using namespace std;
using std::unordered_map;
using std::string;

class Minesweeper {
    /// Fox Static Variables
    static std::mt19937 random;
    static unordered_map<string, sf::Texture> textures;

public:
    /// My Helper Functions:
    unordered_map<string, sf::Sprite> CreateSpriteMap();

    /// Fox Helper Functions:
    // Random functions:
    static int Integer(int min, int max);
    static float Float(float min, float max);
    // Texture Manager:
    static void LoadTexture(string fileName); // LoadTexture("space")
    static sf::Texture& GetTexture(string textureName);
    static void Clear(); // Call once at the end of main();

    /// Test SFML:
    void SFMLTest();
};