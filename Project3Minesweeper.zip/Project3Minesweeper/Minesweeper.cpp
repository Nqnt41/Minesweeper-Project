#include "Minesweeper.h"
/// My Helper Functions:
unordered_map<string, sf::Sprite> Minesweeper::CreateSpriteMap() {
    // Define whatever sprites will be used within:
    sf::Sprite debugSprite(GetTexture("debug"));
    sf::Sprite digitsSprite(GetTexture("digits"));
    sf::Sprite happyFaceSprite(GetTexture("face_happy"));
    sf::Sprite lostFaceSprite(GetTexture("face_lose"));
    sf::Sprite winFaceSprite(GetTexture("face_win"));
    sf::Sprite flagSprite(GetTexture("flag"));
    sf::Sprite mineSprite(GetTexture("mine"));
    sf::Sprite numberOneSprite(GetTexture("number_1"));
    sf::Sprite numberTwoSprite(GetTexture("number_2"));
    sf::Sprite numberThreeSprite(GetTexture("number_3"));
    sf::Sprite numberFourSprite(GetTexture("number_4"));
    sf::Sprite numberFiveSprite(GetTexture("number_5"));
    sf::Sprite numberSixSprite(GetTexture("number_6"));
    sf::Sprite numberSevenSprite(GetTexture("number_7"));
    sf::Sprite numberEightSprite(GetTexture("number_8"));
    sf::Sprite testOneSprite(GetTexture("test_1"));
    sf::Sprite testTwoSprite(GetTexture("test_2"));
    sf::Sprite testThreeSprite(GetTexture("test_3"));
    sf::Sprite hiddenTileSprite(GetTexture("tile_hidden"));
    sf::Sprite revealedTileSprite(GetTexture("tile_revealed"));

    // Add all sprites into a sprite map:
    unordered_map<string, sf::Sprite> sprites;
    sprites["debug"] = debugSprite;
    sprites["digits"] = digitsSprite;
    sprites["happyFace"] = happyFaceSprite;
    sprites["lostFace"] = lostFaceSprite;
    sprites["winFace"] = winFaceSprite;
    sprites["flag"] = flagSprite;
    sprites["mine"] = mineSprite;
    sprites["one"] = numberOneSprite;
    sprites["two"] = numberTwoSprite;
    sprites["three"] = numberThreeSprite;
    sprites["four"] = numberFourSprite;
    sprites["five"] = numberFiveSprite;
    sprites["six"] = numberSixSprite;
    sprites["seven"] = numberSevenSprite;
    sprites["eight"] = numberEightSprite;
    sprites["testOne"] = testOneSprite;
    sprites["testTwo"] = testTwoSprite;
    sprites["testThree"] = testThreeSprite;
    sprites["hiddenTile"] = hiddenTileSprite;
    sprites["revealedTile"] = revealedTileSprite;

    return sprites;
}



/// Fox Helper Functions:
// Random functions:
std::mt19937 Minesweeper::random(time(0));

int Minesweeper::Integer(int min, int max) {
    std::uniform_int_distribution<int> dist(min, max);

    return dist(random);
}

float Minesweeper::Float(float min, float max) {
    std::uniform_real_distribution<float> dist(min, max);

    return dist(random);
}

// Texture Manager:
unordered_map<string, sf::Texture> Minesweeper::textures;

void Minesweeper::LoadTexture(string fileName) {
    string path = "images/";
    path += fileName + ".png";

    textures[fileName].loadFromFile(path);
}

// Basically loads and gets texture at once
sf::Texture& Minesweeper::GetTexture(string textureName) {
    // if the texture DOESN'T exist (hasn't been loaded), load it.
    if (textures.find(textureName) == textures.end()) { // we didn't find it
        LoadTexture(textureName);
    }

    return textures[textureName];
}

void Minesweeper::Clear() {
    textures.clear(); // get rid of all stored objects
}



/// Test SFML:
// SFML Test
void Minesweeper::SFMLTest() {
    sf::RenderWindow window(sf::VideoMode(200, 200), "SFML works!");
    sf::CircleShape shape(100.f);
    shape.setFillColor(sf::Color::Green);

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear();
        window.draw(shape);
        window.display();
    }
}