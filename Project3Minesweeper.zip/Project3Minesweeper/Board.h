#include "Minesweeper.h"
#include <SFML/Graphics.hpp>
#include <fstream>
#include <vector>
#include <iostream>
#include <ctime>
#include <map>
#include <unordered_map>
#pragma once
using namespace std;
using std::unordered_map;
using std::string;

class Tile {
public:
    bool isMine; // Is tile a mine?
    bool isRevealed = false; // Has player clicked on this tile?
    bool isFlagged = false; // Has player flagged this tile?
    bool singularProtect = false; // Used to solve a bug involving revealing adjacent tiles when a tile is flagged
    string spriteName; // What is this tile's sprite (after activation, same basic sprite before then)
    Tile* neighboringTiles[8] = {nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr}; // What tiles neighbor this one? Set all equal to nullptr to begin with.
    int numAdjacentBombs = 0; // How many bombs next to given tile?
    int columnNum; // In which column is this tile in? Used for testing.
    int rowNum; // In which row is this tile in? Used for testing.
    char reference; // Used for testing - one if a mine, zero if not.
};

class Board {
public:
    bool gameLost = false; // Have you lost the game (touched a bomb)?
    bool gameWon = false; // Have you won the game (revealed every tile)?
    bool deactivateTiles = false; // Reveals every tile if true
    bool gameOver = false; // Deactivates the game if true
    bool debugActivated = false; // Is debug on?
    int numColumns = 0; // Number of columns
    int numRows = 0; // Number of rows
    int numMines = 0; // Number of mines
    int numTiles = 0; // Number of tiles
    int flagsAvailable = 0; // Number of flags you can still use
    int width = 0; // Screen width
    int height = 0; // Screen height
    Tile tile; // Tile object for the board
    vector<vector<Tile>> boardLayout; // 2D vector representing the board

    // Functions:
    void LoadBoardData(string board); // Load data for activated board
    void SetNumberAdjacentBombs(); // Determine how many bombs adjacent to main bomb exist
    void SetAdjacentBombSprite(); // Attach sprites to tiles based on number of adjacent bombs
    void DrawBoard(sf::RenderWindow &window, unordered_map<string, sf::Sprite> sprites, sf::Event event); // Create the board based on existing data
    void ResetGame(sf::RenderWindow &window, string board); // Reset the board and replace with chosen board
    bool HasPlayerWon(); // Determine whether the conditions have been met for the player to have won

    // Tests:
    void Print2DVector();
};
