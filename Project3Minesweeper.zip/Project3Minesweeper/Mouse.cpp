#include "Mouse.h"

void Mouse::LeftClick() {

}

void Mouse::RightClick() {

}