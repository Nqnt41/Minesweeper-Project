#include "Board.h"
#include <SFML/Graphics.hpp>
#include <fstream>
#include <vector>
#include <iostream>
#include <ctime>
#include <map>
#include <unordered_map>
#pragma once
using namespace std;
using std::unordered_map;
using std::string;

class Mouse {
public:
    void LeftClick();
    void RightClick();
};