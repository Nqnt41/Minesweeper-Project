#include "Board.h"

/// Functions:
void Board::LoadBoardData(string board) {
    // Data for each row
    vector<Tile> rowData;
    // Convert board input to file structure:
    fstream loadFile;
    // .cfg Version:
    string cfgBoardChoice = "boards/";
    cfgBoardChoice += board + ".cfg";
    // .brd Version:
    string brdBoardChoice = "boards/";
    brdBoardChoice += board + ".brd";

    // Temporary variables to help load file data:
    string tempColumns;
    string tempRows;
    string tempMines;

    // Load data for config file:
    if (cfgBoardChoice == "boards/config.cfg") {
        loadFile.open(cfgBoardChoice);
        getline(loadFile, tempColumns, '\n');
        getline(loadFile, tempRows, '\n');
        getline(loadFile, tempMines, '\n');
        numColumns = stoi(tempColumns);
        numRows = stoi(tempRows);
        numMines = stoi(tempMines);
        flagsAvailable = numMines;
        numTiles = numColumns * numRows;
        width = numColumns * 32;
        height = (numRows * 32) + 100;
        // First, establish all 2D vector points as being non-mines.
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numColumns; j++) {
                tile.isMine = false;
                tile.reference = '0';
                // TODO: Probably dont set spriteName here, do in other function
                tile.spriteName = "tile_revealed";
                rowData.push_back(tile);
            }
            boardLayout.push_back(rowData);
            rowData.clear();
        }
        // Randomly decide what tiles mines should be on
        // Int to show how many mines have been randomly added to the board thus far:
        int numMinesPlaced = 0;
        while (numMinesPlaced < numMines) {
            // Decide width index of new mine:
            int mineColumn = Minesweeper::Integer(0, numColumns - 1);
            // Decide height index of new mine:
            int mineRow = Minesweeper::Integer(0, numRows - 1);
            if (!boardLayout[mineRow][mineColumn].isMine) {
                boardLayout[mineRow][mineColumn].isMine = true;
                boardLayout[mineRow][mineColumn].reference = '1';
                boardLayout[mineRow][mineColumn].spriteName = "mine";
                numMinesPlaced++;
            }
        }
    }
    // Load data for every other file:
    else {
        loadFile.open(brdBoardChoice);
        if (loadFile.is_open()) {
            // Get basic stats: number of mines, columns, rows. Set up 2d vector:
            string numRef;
            int j = 0;
            while (!loadFile.eof()) {
                getline(loadFile, numRef, '\n');
                for (int i = 0; i < numRef.size(); i++) {
                    if (numRef[i] == '1') {
                        numMines++;
                        tile.isMine = true;
                        tile.reference = '1';
                        tile.spriteName = "mine";
                    } else if (numRef[i] == '0') {
                        tile.isMine = false;
                        tile.reference = '0';
                        tile.spriteName = "tile_revealed";
                    }
                    tile.columnNum = i;
                    tile.rowNum = j;
                    rowData.push_back(tile);
                }
                boardLayout.push_back(rowData);
                rowData.clear();
                numColumns = numRef.length();
                numRows++;
                j++;
            }
            numTiles = numColumns * numRows;
            flagsAvailable = numMines;
            width = numColumns * 32;
            height = (numRows * 32) + 100;
        }
        else {
            cout << "Error: Inputted file not opened correctly!";
            abort();
        }
    }
}

void Board::SetNumberAdjacentBombs() {
    /* Adjacent tile structure as follows:
     * 6 5 4
     * 7 X 3
     * 0 1 2
     * All set as nullptr by default, this function just sets the rest. */

    for (int i = 0; i < numRows; i++) {
        for (int j = 0; j < numColumns; j++) {
            // If tile is in the top left:
            if (i == 0 && j == 0) {
                boardLayout[i][j].neighboringTiles[1] = &boardLayout[i + 1][j]; // 1
                boardLayout[i][j].neighboringTiles[2] = &boardLayout[i + 1][j + 1]; // 2
                boardLayout[i][j].neighboringTiles[3] = &boardLayout[i][j + 1]; // 3
            }
            // If tile is in the top right:
            else if (i == 0 && j == numColumns - 1) {
                boardLayout[i][j].neighboringTiles[0] = &boardLayout[i + 1][j - 1]; // 0
                boardLayout[i][j].neighboringTiles[1] = &boardLayout[i + 1][j]; // 1
                boardLayout[i][j].neighboringTiles[7] = &boardLayout[i][j - 1]; // 7
            }
            // If tile is in the top:
            else if (i == 0) {
                boardLayout[i][j].neighboringTiles[0] = &boardLayout[i + 1][j - 1]; // 0
                boardLayout[i][j].neighboringTiles[1] = &boardLayout[i + 1][j]; // 1
                boardLayout[i][j].neighboringTiles[2] = &boardLayout[i + 1][j + 1]; // 2
                boardLayout[i][j].neighboringTiles[3] = &boardLayout[i][j + 1]; // 3
                boardLayout[i][j].neighboringTiles[7] = &boardLayout[i][j - 1]; // 7
            }
            // If tile is on the bottom left:
            else if (i == numRows - 1 && j == 0) {
                boardLayout[i][j].neighboringTiles[3] = &boardLayout[i][j + 1]; // 3
                boardLayout[i][j].neighboringTiles[4] = &boardLayout[i - 1][j + 1]; // 4
                boardLayout[i][j].neighboringTiles[5] = &boardLayout[i - 1][j]; // 5
            }
            // If tile is on the bottom right:
            else if (i == numRows - 1 && j == numColumns - 1) {
                boardLayout[i][j].neighboringTiles[5] = &boardLayout[i - 1][j]; // 5
                boardLayout[i][j].neighboringTiles[6] = &boardLayout[i - 1][j - 1]; // 6
                boardLayout[i][j].neighboringTiles[7] = &boardLayout[i][j - 1]; // 7
            }
            // If tile is on the bottom:
            else if (i == numRows - 1) {
                boardLayout[i][j].neighboringTiles[3] = &boardLayout[i][j + 1]; // 3
                boardLayout[i][j].neighboringTiles[4] = &boardLayout[i - 1][j + 1]; // 4
                boardLayout[i][j].neighboringTiles[5] = &boardLayout[i - 1][j]; // 5
                boardLayout[i][j].neighboringTiles[6] = &boardLayout[i - 1][j - 1]; // 6
                boardLayout[i][j].neighboringTiles[7] = &boardLayout[i][j - 1]; // 7
            }
            // If tile is on left:
            else if (j == 0) {
                boardLayout[i][j].neighboringTiles[1] = &boardLayout[i + 1][j]; // 1
                boardLayout[i][j].neighboringTiles[2] = &boardLayout[i + 1][j + 1]; // 2
                boardLayout[i][j].neighboringTiles[3] = &boardLayout[i][j + 1]; // 3
                boardLayout[i][j].neighboringTiles[4] = &boardLayout[i - 1][j + 1]; // 4
                boardLayout[i][j].neighboringTiles[5] = &boardLayout[i - 1][j]; // 5
            }
            // If tile is on the right:
            else if (j == numColumns - 1) {
                boardLayout[i][j].neighboringTiles[0] = &boardLayout[i + 1][j - 1]; // 0
                boardLayout[i][j].neighboringTiles[1] = &boardLayout[i + 1][j]; // 1
                boardLayout[i][j].neighboringTiles[5] = &boardLayout[i - 1][j]; // 5
                boardLayout[i][j].neighboringTiles[6] = &boardLayout[i - 1][j - 1]; // 6
                boardLayout[i][j].neighboringTiles[7] = &boardLayout[i][j - 1]; // 7
            }
            // If tile is in the center:
            else {
                boardLayout[i][j].neighboringTiles[0] = &boardLayout[i + 1][j - 1]; // 0
                boardLayout[i][j].neighboringTiles[1] = &boardLayout[i + 1][j]; // 1
                boardLayout[i][j].neighboringTiles[2] = &boardLayout[i + 1][j + 1]; // 2
                boardLayout[i][j].neighboringTiles[3] = &boardLayout[i][j + 1]; // 3
                boardLayout[i][j].neighboringTiles[4] = &boardLayout[i - 1][j + 1]; // 4
                boardLayout[i][j].neighboringTiles[5] = &boardLayout[i - 1][j]; // 5
                boardLayout[i][j].neighboringTiles[6] = &boardLayout[i - 1][j - 1]; // 6
                boardLayout[i][j].neighboringTiles[7] = &boardLayout[i][j - 1]; // 7
            }
        }
    }
    for (int i = 0; i < numRows; i++) {
        for (int j = 0; j < numColumns; j++) {
            for (int k = 0; k < 8; k++) {
                if (boardLayout[i][j].neighboringTiles[k] != nullptr && boardLayout[i][j].neighboringTiles[k]->isMine) {
                    boardLayout[i][j].numAdjacentBombs++;
                }
            }
        }
    }
}

void Board::SetAdjacentBombSprite() {
    SetNumberAdjacentBombs();

    for (int i = 0; i < numRows; i++) {
        for (int j = 0; j < numColumns; j++) {
            if (!boardLayout[i][j].isMine) {
                if (boardLayout[i][j].numAdjacentBombs == 0) {
                    for (int k = 0; k < 8; k++) {
                        if (boardLayout[i][j].isRevealed && boardLayout[i][j].neighboringTiles[k] != nullptr &&
                            !boardLayout[i][j].neighboringTiles[k]->isRevealed) {
                            if (!boardLayout[i][j].neighboringTiles[k]->singularProtect) {
                                boardLayout[i][j].neighboringTiles[k]->isRevealed = true;
                            }
                            if (HasPlayerWon()) {
                                gameWon = true;
                                deactivateTiles = true;
                            }
                        }
                    }
                } else if (boardLayout[i][j].numAdjacentBombs == 8) {
                    boardLayout[i][j].spriteName = "number_1";
                } else if (boardLayout[i][j].numAdjacentBombs == 7) {
                    boardLayout[i][j].spriteName = "number_2";
                } else if (boardLayout[i][j].numAdjacentBombs == 6) {
                    boardLayout[i][j].spriteName = "number_3";
                } else if (boardLayout[i][j].numAdjacentBombs == 5) {
                    boardLayout[i][j].spriteName = "number_4";
                } else if (boardLayout[i][j].numAdjacentBombs == 4) {
                    boardLayout[i][j].spriteName = "number_5";
                } else if (boardLayout[i][j].numAdjacentBombs == 3) {
                    boardLayout[i][j].spriteName = "number_6";
                } else if (boardLayout[i][j].numAdjacentBombs == 2) {
                    boardLayout[i][j].spriteName = "number_7";
                } else if (boardLayout[i][j].numAdjacentBombs == 1) {
                    boardLayout[i][j].spriteName = "number_8";
                }
            }
        }
    }
}

void Board::DrawBoard(sf::RenderWindow &window, unordered_map<string, sf::Sprite> sprites, sf::Event event) {
    SetAdjacentBombSprite();

    sf::Vector2i mousePosition = sf::Mouse::getPosition(window);

    // A few arrays at play:
    // First, create background for tile area:
    for (int i = 0; i < boardLayout.size(); i++) {
        for (int j = 0; j < boardLayout[0].size(); j++) {
            sf::Sprite backgroundSprite = sprites["revealedTile"];
            backgroundSprite.setPosition((j * 32.0), (i * 32.0));
            // Now with all other things set up, the sprite:
            window.draw(backgroundSprite);
        }
    }

    // Then, place the tile specifics over the background.
    for (int i = 0; i < boardLayout.size(); i++) {
        for (int j = 0; j < boardLayout[0].size(); j++) {
            sf::Sprite currentSprite(Minesweeper::GetTexture(boardLayout[i][j].spriteName));
            currentSprite.setPosition((j * 32), (i * 32));
            // Now with all other things set up, the sprite:
            window.draw(currentSprite);
        }
    }

    // Hide the below sprites with the tile_hidden sprite:
    if (!deactivateTiles) {
        for (int i = 0; i < boardLayout.size(); i++) {
            for (int j = 0; j < boardLayout[0].size(); j++) {
                if (!boardLayout[i][j].isRevealed) {
                    sf::Sprite currentSprite = sprites["hiddenTile"];
                    currentSprite.setPosition((j * 32), (i * 32));
                    // Now with all other things set up, the sprite:
                    window.draw(currentSprite);

                    if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                        sf::FloatRect tileHitbox = currentSprite.getGlobalBounds();
                        if (tileHitbox.contains(mousePosition.x, mousePosition.y) && !boardLayout[i][j].isFlagged && gameLost == false) {
                            boardLayout[i][j].isRevealed = true;
                            if (boardLayout[i][j].isMine) {
                                gameLost = true;
                                deactivateTiles = true;
                            } else if (!boardLayout[i][j].isMine) {
                                if (HasPlayerWon()) {
                                    gameWon = true;
                                    deactivateTiles = true;
                                }
                            }
                        }
                    }
                    if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Right) {
                        sf::FloatRect tileHitbox = currentSprite.getGlobalBounds();
                        if (tileHitbox.contains(mousePosition.x, mousePosition.y) && gameLost == false) {
                            if (!boardLayout[i][j].isRevealed) {
                                if (boardLayout[i][j].isFlagged) {
                                    boardLayout[i][j].isFlagged = false;
                                    flagsAvailable++;
                                    boardLayout[i][j].singularProtect = true;
                                } else if (!boardLayout[i][j].isFlagged) {
                                    boardLayout[i][j].isFlagged = true;
                                    flagsAvailable--;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Place any flag sprites:
    for (int i = 0; i < boardLayout.size(); i++) {
        for (int j = 0; j < boardLayout[0].size(); j++) {
            if (boardLayout[i][j].isFlagged) {
                sf::Sprite flagSprite = sprites["flag"];
                flagSprite.setPosition((j * 32), (i * 32));
                // Now with all other things set up, the sprite:
                window.draw(flagSprite);
            }
        }
    }

    // Finally, for the debug implementation, draw only time mines if debug mode is active:
    if (debugActivated) {
        for (int i = 0; i < boardLayout.size(); i++) {
            for (int j = 0; j < boardLayout[0].size(); j++) {
                if (boardLayout[i][j].isMine) {
                    sf::Sprite currentSprite = sprites["mine"];
                    currentSprite.setPosition((j * 32), (i * 32));
                    // Now with all other things set up, the sprite:
                    window.draw(currentSprite);
                }
            }
        }
    }

    // Individually add the elements on the bottom of the screen:
    // Face sprite
    sf::Sprite faceSprite;
    if (gameLost) {
        faceSprite = sprites["lostFace"];
        faceSprite.setOrigin(32, 32);
        faceSprite.setPosition(width / 2, height - 68);
        window.draw(faceSprite);
    }
    else if (gameWon) {
        faceSprite = sprites["winFace"];
        faceSprite.setOrigin(32, 32);
        faceSprite.setPosition(width / 2, height - 68);
        window.draw(faceSprite);
    }
    else {
        faceSprite = sprites["happyFace"];
        faceSprite.setOrigin(32, 32);
        faceSprite.setPosition(width / 2, height - 68);
        window.draw(faceSprite);
    }
    // Reset button functionality - press at any time to reset game:
    if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
        sf::FloatRect faceHitbox = faceSprite.getGlobalBounds();
        if (faceHitbox.contains(mousePosition.x, mousePosition.y)) {
            ResetGame(window, "config");
        }
    }

    // Digits sprite
    sf::Sprite digitsNegativeSprite = sprites["digits"];
    digitsNegativeSprite.setPosition(0, height - 100);
    sf::Sprite digitsOnesSprite = sprites["digits"];
    digitsOnesSprite.setPosition(63, height - 100);
    sf::Sprite digitsTensSprite = sprites["digits"];
    digitsTensSprite.setPosition(42, height - 100);
    sf::Sprite digitsHundredsSprite = sprites["digits"];
    digitsHundredsSprite.setPosition(21, height - 100);

    int flagsCopy = flagsAvailable;
    if (flagsAvailable < 0) {
        flagsCopy = flagsAvailable * -1;
    }
    int onesDigit = flagsCopy % 10;
    flagsCopy /= 10;
    int tensDigit = flagsCopy % 10;
    flagsCopy /= 10;
    int hundredsDigit = flagsCopy % 10;

    if (flagsAvailable >= 0) {
        digitsNegativeSprite.setTextureRect(sf::Rect<int>(-21, 0, 21, 32));
    } else {
        digitsNegativeSprite.setTextureRect(sf::Rect<int>(210, 0, 21, 32));
    }
    digitsOnesSprite.setTextureRect(sf::Rect<int>(21 * onesDigit, 0, 21, 32));
    digitsTensSprite.setTextureRect(sf::Rect<int>(21 * tensDigit, 0, 21, 32));
    digitsHundredsSprite.setTextureRect(sf::Rect<int>(21 * hundredsDigit, 0, 21, 32));

    window.draw(digitsNegativeSprite);
    window.draw(digitsOnesSprite);
    window.draw(digitsTensSprite);
    window.draw(digitsHundredsSprite);

    // Debug sprite
    sf::Sprite debugSprite = sprites["debug"];
    debugSprite.setOrigin(32, 32);
    debugSprite.setPosition(width - 224, height - 68);
    window.draw(debugSprite);
    // Debug functionality - set hitbox and effect.
    if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
        sf::FloatRect debugHitbox = debugSprite.getGlobalBounds();
        if (debugHitbox.contains(mousePosition.x, mousePosition.y)) {
            if (debugActivated) {
                debugActivated = false;
            } else {
                debugActivated = true;
            }
        }
    }

    // Test 1 sprite
    sf::Sprite testOneSprite = sprites["testOne"];
    testOneSprite.setOrigin(32, 32);
    testOneSprite.setPosition(width - 160, height - 68);
    window.draw(testOneSprite);
    // Test 1 functionality - press to load testboard1:
    if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
        sf::FloatRect testOneHitbox = testOneSprite.getGlobalBounds();
        if (testOneHitbox.contains(mousePosition.x, mousePosition.y)) {
            ResetGame(window, "testboard1");
        }
    }

    // Test 2 sprite
    sf::Sprite testTwoSprite = sprites["testTwo"];
    testTwoSprite.setOrigin(32, 32);
    testTwoSprite.setPosition(width - 96, height - 68);
    window.draw(testTwoSprite);
    // Test 2 functionality - press to load testboard2:
    if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
        sf::FloatRect testTwoHitbox = testTwoSprite.getGlobalBounds();
        if (testTwoHitbox.contains(mousePosition.x, mousePosition.y)) {
            ResetGame(window, "testboard2");
        }
    }

    // Test 3 sprite
    sf::Sprite testThreeSprite = sprites["testThree"];
    testThreeSprite.setOrigin(32, 32);
    testThreeSprite.setPosition(width - 32, height - 68);
    window.draw(testThreeSprite);
    // Test 3 functionality - press to load testboard3:
    if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
        sf::FloatRect testThreeHitbox = testThreeSprite.getGlobalBounds();
        if (testThreeHitbox.contains(mousePosition.x, mousePosition.y)) {
            ResetGame(window, "testboard3");
        }
    }
}

bool Board::HasPlayerWon() {
    int numRevealTiles = numTiles;
    int trueNumMines = 0;
    for (int i = 0; i < boardLayout.size(); i++) {
        for (int j = 0; j < boardLayout[0].size(); j++) {
            if (boardLayout[i][j].isRevealed) {
                numRevealTiles--;
            }
            if (boardLayout[i][j].isMine) {
                numRevealTiles--;
                trueNumMines++;
            }
        }
    }
    if (numRevealTiles == 0) {
        return true;
    }
    else {
        return false;
    }
}


void Board::ResetGame(sf::RenderWindow &window, string board) {
    // Close window to reset game w/ new board:
    window.close();
    // Reset board conditions to default:
    boardLayout.clear();
    gameLost = false;
    gameWon = false;
    deactivateTiles = false;
    gameOver = false;
    debugActivated = false;
    numColumns = 0;
    numRows = 0;
    numMines = 0;
    numTiles = 0;
    flagsAvailable = 0;
    width = 0;
    height = 0;
    // Load board data into vector:
    LoadBoardData(board);
    // Load new window:
    window.create(sf::VideoMode(width, height), "Minesweeper");
}



/// Tests:
void Board::Print2DVector() {
    for (int i = 0; i < boardLayout.size(); i++) {
        for (int j = 0; j < boardLayout[0].size(); j++) {
            cout << boardLayout[i][j].reference << " ";
        }
        cout << endl;
    }
}